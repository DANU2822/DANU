// BY 𝗦𝗜𝗥_𝗕𝗟𝗔𝗭𝗘'𝗦 𝗛𝗨𝗕²⁰²⁵ 👑☃️
require("./lib/module")

// SETTINGS
global.owner = "263788848481"
global.ownername = "*_`𝗦𝗜𝗥_𝗕𝗟𝗔𝗭𝗘'𝗦 𝗛𝗨𝗕²⁰²⁵-V1👑🤡*"
global.nomorbot = "263788848481"
global.namaCreator = "*_`POWERED BY 𝗦𝗜𝗥_𝗕𝗟𝗔𝗭𝗘'𝗦 𝗛𝗨𝗕²⁰²⁵ "
global.Dec = "𝗦𝗜𝗥_𝗕𝗟𝗔𝗭𝗘'𝗦 𝗛𝗨𝗕²⁰²⁵👑🤡"
global.autoJoin = false
global.antilink = false

// THUMBNAIL 
global.imageurl = 'https://files.catbox.moe/cydxb4.jpg'
global.channel = `https://whatsapp.com/channel/0029Vb1Z35n5K3zNXrzvrt39'

// STICKER
global.packname = "AM 𝗦𝗜𝗥_𝗕𝗟𝗔𝗭𝗘'𝗦 𝗛𝗨𝗕²⁰²⁵👑🤡 HOW CAN I HELP YOU"
global.author = "FEEL THE NUMB"
global.jumlah = "1"



// 𝗥𝗘𝗦𝗣𝗢𝗡𝗦𝗘
global.onlyprem = `*THIS IS ONLY AVAILABLE FOR PREMIUM USER'S*`
global.onlyown = `*THIS IS ONLY AVAILABLE FOR THOSE WHO ARE OWNER'S ALREADY*`
global.onlygroup = `*THIS IS ONLY AVAILABLE FOR MY OWNER'S*`
global.onlyadmin = `*RESERVED FOR ADMINS ONLY*`
global.notext = `*KING IS DOING HIS JOB PLEASE WAIT*`
global.noadmin = `*MAKE ME AN ADMIN AND I TAKE ACTION*`
global.succes = `*𝗗𝗢𝗡𝗘*`
global.invalid = `*𝗦𝗢𝗥𝗥𝗬 𝗜𝗡𝗩𝗔𝗟𝗜𝗗 𝗡𝗨𝗠𝗕𝗘𝗥*`
global.bugrespon = `*ʜᴇʏ 🤖ᴛʜɪs ɪs 𝗦𝗜𝗥_𝗕𝗟𝗔𝗭𝗘'𝗦 𝗛𝗨𝗕²⁰²⁵👑🤡 bug bot ʙᴜɢɢɪɴɢ ʜᴀs ʙᴇᴇɴ ᴄᴏᴍᴘʟᴇᴛᴇᴅ ᴘʟᴇᴀsᴇ ᴡᴀɪᴛ 5 ᴍɪɴᴜᴛᴇs ᴛᴏ ᴀᴠᴏɪᴅ ʙᴀɴ ᴛʜɪs ɪs ɴᴇᴄᴇssᴀʀʏ!! ✅*`

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})